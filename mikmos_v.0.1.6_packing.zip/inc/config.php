<?php 
/** 
Yedin Abu Shafa 
Kontak WA: 081802161315
**/
$_ROUTER 	= "MIKMOS";
$_LANG 		= "id";
$_TIMER		= "1200";
?>