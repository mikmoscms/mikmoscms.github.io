
Logo :
<img src="<?php echo $v_logo;?>" style="height:30px;border:0;">

Hotspotname :
<?php echo $v_spot;?>

No.HP :
<?php echo $v_hp;?>

Username :
<?php echo $v_user;?>

Password :
<?php echo $v_pass;?>

Validity :
<?php echo $v_valid;?>

Time Limit :
<?php echo $v_tlimit;?>

Data Limit :
<?php echo $v_dlimit;?>

Price :
<?php echo $v_harga;?>

QR Code :
<img src="<?php echo $v_qrcode ?>">

Number Voucher:
<?php echo $v_num;?>
<span id="num"><?php echo " [$v_num]";?></span>

Pilihan :
$v_pil = "vc"
username=password

$v_pil = "up"
username&password
