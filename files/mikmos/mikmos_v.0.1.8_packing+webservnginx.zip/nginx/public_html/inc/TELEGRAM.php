<?php
/** 
Yedin Abu Shafa 
Kontak WA: 081802161315
**/
$_STATTELEG	= "0";
$_TELEGRAM	= "TELEGRAM";
$_BOT_API	= "";
$_CHAT_ID	= "";
?>