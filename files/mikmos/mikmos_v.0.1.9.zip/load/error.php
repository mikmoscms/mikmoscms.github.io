
<div class="row">
<div class="col-sm-12">
<div class="panel">
<header class="panel-heading">

</header>
<div class="panel-body"

<div class="col-md-12">
<div class="text-center">
<h1 class="color-white f-s-75">404</h1>

<h3 class="text-uppercase">Page not found </h3>
<p class="text-muted m-t-30 m-b-30">Mohon maaf sepertinya tidak ada!</p>
<a class="btn btn-info btn-rounded waves-effect waves-light m-b-40" href="./">Kembali</a> 
</div>
</div>

</div>
</div>
</div>