# MIKMOS cms

Description of MIKMOS cms
- @author [@Yedin Abu Shafa](https://fb.me/yedin.mikmos.3) - mikmoscms@gmail.com <http://mikmos.my.id>
- @copyright (c) 2018, MIKMOS Team.
- @license https://opensource.org/licenses/gpl-license GNU Public License
- @for AllFiles MIKMOScms

----
![MIKMOScms](https://image.ibb.co/hJxZDA/Screenshot-2018-10-19-MIKMOS-CMS-Mikrotik-Monitoring-System-2.png)

---- 
Fitur:
----
- Installasi mudah
- Hotspot Monitoring
- Multi Router Mikrotik
- Generate voucher & print
- Style Template Voucher
- Kirim Notif Telegram
- Backup Mikrotik Kirim ke Email
- Multi Bahasa (Google Translate)
- Multi Themes (Pilihan Tema Mikmos)
- Import vouchers dengan excel (Export dari userman/manual excel)
- Auto Update Online/Offline (manual)

----
Sistem yang dibutuhkan
----
Requirements
- OS Linux/Windows
- PHP Version 5.6 atau lebih
  - PHP-CURL
  - PHP-ZIP

----
MIKMOS Online
----
Aplikasi ini dikelola oleh  [@Yedin di [facebook](https://fb.me/yedin.mikmos.3)
