
<?php 
$_ROUTER = "EYTALASE";
$_LANG = "id";
$_TIMER= "1200";
?>