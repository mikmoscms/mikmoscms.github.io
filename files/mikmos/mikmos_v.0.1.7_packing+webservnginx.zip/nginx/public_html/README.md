# MIKMOS cms

Description of MIKMOS cms
- @author Yedin Abu Shafa mikmoscms@gmail.com <http://mikmos.my.id>
- @copyright Copyright (c) 2018, MIKMOS Team.
- @license https://opensource.org/licenses/gpl-license GNU Public License
- @for AllFiles MIKMOScms

----
![MIKMOScms](https://image.ibb.co/hJxZDA/Screenshot-2018-10-19-MIKMOS-CMS-Mikrotik-Monitoring-System-2.png)

----
Aplikasi ini dikelola oleh [@Yedin](https://fb.me/yedin.mikmos.3)

---- 
Fitur:
----
- Installasi mudah
- Hotspot
- Multi Router Mikrotik
- Generate voucher & print
- Style Template Voucher

----
Sistem yang dibutuhkan
----
Requirements
- Linux or Windows OS
- PHP Version 5.6 atau lebih
- PHP-CURL
- PHP-ZIP

----
MIKMOS Online
----
hubungi Yedin di [facebook](https://facebook.com/yedin.mikmos.3)
