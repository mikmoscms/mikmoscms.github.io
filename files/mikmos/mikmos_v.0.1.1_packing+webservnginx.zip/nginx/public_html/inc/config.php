<?php 
error_reporting(0);
@session_start();
@ob_start("ob_gzhandler");
@date_default_timezone_set("Asia/Bangkok");
@ini_set('max_execution_time', 300);
$_ROUTER = "EYTALASE";
$_LANG = "id";
$_TIMER= "1200";
?>