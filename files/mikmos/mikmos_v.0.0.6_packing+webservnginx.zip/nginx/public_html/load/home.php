<?php
@session_start();
error_reporting(0);
if(!isset($_SESSION['connect'])){
 echo "<meta http-equiv='refresh' content='0;url=./' />";
}
$mikmosLoadJ = $API->comm("/system/clock/print");
$mikmosJ = $mikmosLoadJ[0];
$mikmosLoadResource = $API->comm("/system/resource/print");
$mikmosResource = $mikmosLoadResource[0];
$mikmosLoadRB = $API->comm("/system/routerboard/print");
$mikmosRB = $mikmosLoadRB[0];
$mikmosLoadActive = $API->comm("/ip/hotspot/active/print", array( "count-only" => "")); if($mikmosLoadActive < 2 ){$hunit = "item"; }elseif($mikmosLoadActive > 1){ $hunit = "items"; }
$mikmosTotUs = $API->comm("/ip/hotspot/user/print", array( "count-only" => "")); if($mikmosTotUs < 2 ){$uunit = "item"; }elseif($mikmosTotUs > 1){ $uunit = "items";}
$bg_array = array("#CEED9D","#ECED9D","#EDCF9D","#EC9CA7","#fdd752","#a48ad4","#aec785","#1fb5ac","#fa8564");
 ?>
 <div id="reloadHomex">
 
                <div class="row">
                    <div class="col-md-3">
                        <div class="card p-20" style="background-color:<?php echo $bg_array[rand(0,8)];?>">
                            <div class="media widget-ten">
                                <div class="media-left meida media-middle">
                                    <span  class="color-white"><i class="fa fa-bar-chart f-s-40"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2 class="color-white"><?php echo $mikmosLoadActive;?></h2>
                                    <p class="m-b-0 color-white"><?php echo __USERS_ACTIVE;?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-20" style="background-color:<?php echo $bg_array[rand(0,8)];?>">
                            <div class="media widget-ten">
                                <div class="media-left meida media-middle">
                                    <span  class="color-white"><i class="fa fa-users f-s-40"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2 class="color-white"><?php echo $mikmosTotUs;?></h2>
                                    <p class="m-b-0 color-white"><?php echo __USERS;?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-20" style="background-color:<?php echo $bg_array[rand(0,8)];?>">
                            <div class="media widget-ten">
                                <div class="media-left meida media-middle">
                                    <span  class="color-white"><i class="fa fa-clock-o f-s-40"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2 class="color-white"><?php echo formatDTM($mikmosResource['uptime'])?></h2>
                                    <p class="m-b-0 color-white"><?php echo __UPTIME;?>	</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-20" style="background-color:<?php echo $bg_array[rand(0,8)];?>">
                            <div class="media widget-ten">
                                <div class="media-left meida media-middle">
                                    <span  class="color-white"><i class="fa fa-line-chart f-s-40"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2 class="color-white"><?php echo $mikmosResource['cpu-load']?>%</h2>
                                    <p class="m-b-0 color-white"><?php echo __CPU_LOAD;?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				
	
                <div class="row">
				<div class="col-lg-6">
                        <div class="card">
                            <div class="card-title">
                                <h4><?php echo __SYSTEM_RESOURCES;?></h4>
                            </div>
                            <div class="card-body">
                                <div class="message-center">
					 <table class="table table-striped" style="font-size:80%;">
					 <tr><td><?php echo __PLATFORM;?></td><td><?php echo $mikmosResource['platform'];?></td></tr>
					 <tr><td><?php echo __MODEL;?></td><td><?php echo $mikmosRB['model']?></td></tr>
					 <tr><td><?php echo __VERSI;?></td><td><?php echo $mikmosResource['version'];?></td></tr>
					 <tr><td><?php echo __BOARD_NAME;?></td><td><?php echo $mikmosResource['board-name'];?></td></tr>
					 <tr><td><?php echo __ARCHITECTURE;?></td><td><?php echo $mikmosResource['architecture-name']?></td></tr>
					 <tr><td><?php echo __CPU;?></td><td><?php echo $mikmosResource['cpu']?></td></tr>
					 <tr><td><?php echo __CPU_COUNT;?></td><td><?php echo $mikmosResource['cpu-count']?></td></tr>
					 <tr><td><?php echo __MEMORY;?></td><td><?php echo formatBytes($mikmosResource['free-memory'],2)?>/<?php echo formatBytes($mikmosResource['total-memory'],2)?></td></tr>
					 <tr><td><?php echo __HDD;?></td><td><?php echo formatBytes($mikmosResource['free-hdd-space'],2)?>/<?php echo formatBytes($mikmosResource['total-hdd-space'],2)?></td></tr>
					 <tr><td><?php echo __BULID_TIME;?></td><td><?php echo $mikmosResource['build-time']?></td></tr>
					 </table>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
				<div class="col-lg-6">
                        <div class="card">
                            <div class="card-title">
                                <h4><?php echo __LOG_ACTIVITY;?></h4>
                            </div>
                            <div class="card-body">
                                <div class="message-center">
						 <table class="table table-hover" style="font-size:80%;">
						 <?php
						 $vlogging = $API->comm("/system/logging/print", array("?prefix" => "->",));
						 $logging = $vlogging[0];
						 if($logging['prefix'] == "->"){}else{ $API->comm("/system/logging/add", array("action" => "disk","prefix" => "->","topics" => "hotspot,info,debug",)); }
						 $vlog = $API->comm("/log/print", array("?topics" => "hotspot,info,debug",));
						 $log = array_reverse($vlog);
						 $TotalReg = count($vlog);
						 for ($i=0; $i<$TotalReg; $i++){
						 echo "<tr>";
						 echo "<td>" . $log[$i]['time'];echo "</td>";
						 echo "<td>" . $log[$i]['message'];echo "</td>";
						 echo "</tr>";
						 }
						?>
						</table>
						</div>
                            </div>
                        </div>
                    </div>
					
                    </div>
			
</div>		<script type="text/javascript">
    setTimeout(function(){
       window.location.reload(1);
    }, 30000);
</script>