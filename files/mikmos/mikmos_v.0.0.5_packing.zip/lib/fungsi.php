<?php
//COMPRESS PAGE
function compresspage($buffer) {
    $search = array(
		'/\n/',			// replace end of line by a space
		'/\>[^\S ]+/s',		// strip whitespaces after tags, except space
		'/[^\S ]+\</s',		// strip whitespaces before tags, except space
	 	'/(\s)+/s'		// shorten multiple whitespace sequences
    );
    $replace = array(
		' ',
		'>',
	 	'<',
	 	'\\1'
    );
    $buffer = preg_replace($search, $replace, $buffer);
    return $buffer;
//return preg_replace(array('/<!--(.*)-->/Uis',"/[[:blank:]]+/"),array('',' '),str_replace(array("n","r","t"),'',$buffer));
}

// function  format bytes
function formatBytes($size, $decimals = 0){
$unit = array(
'0' => 'Byte',
'1' => 'KiB',
'2' => 'MiB',
'3' => 'GiB',
'4' => 'TiB',
'5' => 'PiB',
'6' => 'EiB',
'7' => 'ZiB',
'8' => 'YiB'
);

for($i = 0; $size >= 1024 && $i <= count($unit); $i++){
$size = $size/1024;
}

return round($size, $decimals).' '.$unit[$i];
}

// function  format bytes2
function formatBytes2($size, $decimals = 0){
$unit = array(
'0' => 'Byte',
'1' => 'KB',
'2' => 'MB',
'3' => 'GB',
'4' => 'TB',
'5' => 'PB',
'6' => 'EB',
'7' => 'ZB',
'8' => 'YB'
);

for($i = 0; $size >= 1000 && $i <= count($unit); $i++){
$size = $size/1000;
}

return round($size, $decimals).''.$unit[$i];
}


// function  format bites
function formatBites($size, $decimals = 0){
$unit = array(
'0' => 'bps',
'1' => 'kbps',
'2' => 'Mbps',
'3' => 'Gbps',
'4' => 'Tbps',
'5' => 'Pbps',
'6' => 'Ebps',
'7' => 'Zbps',
'8' => 'Ybps'
);

for($i = 0; $size >= 1000 && $i <= count($unit); $i++){
$size = $size/1000;
}

return round($size, $decimals).' '.$unit[$i];
}



// encrypt decript

function _en($string, $key=128) {
	$result = '';
	for($i=0, $k= strlen($string); $i<$k; $i++) {
		$char = substr($string, $i, 1);
		$keychar = substr($key, ($i % strlen($key))-1, 1);
		$char = chr(ord($char)+ord($keychar));
		$result .= $char;
	}
	return base64_encode($result);
}
function _de($string, $key=128) {
	$result = '';
	$string = base64_decode($string);
	for($i=0, $k=strlen($string); $i< $k ; $i++) {
		$char = substr($string, $i, 1);
		$keychar = substr($key, ($i % strlen($key))-1, 1);
		$char = chr(ord($char)-ord($keychar));
		$result .= $char;
	}
	return $result;
}

// encrypt decript

function encrypt($string, $key=128) {
	$result = '';
	for($i=0, $k= strlen($string); $i<$k; $i++) {
		$char = substr($string, $i, 1);
		$keychar = substr($key, ($i % strlen($key))-1, 1);
		$char = chr(ord($char)+ord($keychar));
		$result .= $char;
	}
	return base64_encode($result);
}
function decrypt($string, $key=128) {
	$result = '';
	$string = base64_decode($string);
	for($i=0, $k=strlen($string); $i< $k ; $i++) {
		$char = substr($string, $i, 1);
		$keychar = substr($key, ($i % strlen($key))-1, 1);
		$char = chr(ord($char)-ord($keychar));
		$result .= $char;
	}
	return $result;
}
// Reformat date time MikroTik

function formatDTM($dtm){
$val_conver = $dtm; 
$new_format = str_replace("s", "", str_replace("m", ":", str_replace("h", ":", str_replace("d", "d ", str_replace("w", "w ", $val_conver)))));
return $new_format;
}
//Loading
function Loading($url,$time,$title){
if(empty($time)){$urlnya='<meta http-equiv="refresh" content="0; url='.$url.'"/>';}else{$urlnya='<meta http-equiv="refresh" content="'.$time.'; url='.$url.'"/>';}
if(empty($title)){$titlenya='Loading...';}else{$titlenya=$title;}
$loading = ''.$urlnya.'<div class="row"><div class="main-content"><div class="panel"><i class="fa fa-refresh fa-spin"></i> <span>'.$titlenya.'</span></div></div></div>';
return $loading;
}
function ganti_spasi($str){
$str =	str_replace(' ', '_', $str);
return $str;
}

function install_ipmk($link){
$rep=opendir($link);
while ($file = readdir($rep)) {
if($file != '..' && $file !='.' && $file !=''){
if ($file !='index.php' && $file !='index.html' && $file !='.htaccess'){
if(!is_dir($file)){
return $file;	
}}}} 
}


function versi_off(){
$url = "./db/versi.xml";
$sUrl = file_get_contents($url, true);
$xml = simplexml_load_string($sUrl);
return $xml->mikmos->versi;
}
function versi_on(){
$url = "https://mikmos.tk/versi/versi.xml";
$sUrl = file_get_contents($url, true);
$xml = simplexml_load_string($sUrl);
return $xml->mikmos->versi;
}
function update_versi(){
if(versi_on()==versi_off()){echo'OK';}else{echo'update';}
}
function load_router($router, $dir, $on){
$rep=opendir($dir);
while ($file = readdir($rep)) {
 if($file != '..' && $file !='.' && $file !=''){
 if ($file !='index.php' && $file !='index.html' && $file !='.htaccess'){
 if(!is_dir($file)){
	 if($on=='on'){
if ($router==substr($file, 0, -4)){   
echo ' 
                        <div class="card p-20" style="background-color:#fa8564">
                            <div class="media widget-ten">
                                <div class="media-left meida media-middle">
                                    <span  class="color-white"><i class="fa fa-server f-s-40"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2 class="color-white">'.substr($file, 0, -4).'</h2>
<p class="m-b-0 color-white"><a class=" color-white" href="#" title="'.__ENABLE.' Router '.substr($file, 0, -4).'">'.__ENABLE.' <i class="fa fa-unlock"></i> </a></p>
<p class="m-b-0 color-white"><a class=" color-white" href="./settings.php?index=mikrotik_ae&id='.substr($file, 0, -4).'" title="'.__EDIT.' Router '.substr($file, 0, -4).'">'.__EDIT.' <i class="fa fa-edit"></i> </a></p>
                                </div>
                            </div>
                        </div>';
}}
	 if($on=='off'){
if ($router!==substr($file, 0, -4)){   
echo '
                        <div class="card p-20" style="background-color:#1fb5ac">
                            <div class="media widget-ten">
                                <div class="media-left meida media-middle">
                                    <span  class="color-white"><i class="fa fa-server f-s-40"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2 class="color-white">'.substr($file, 0, -4).'</h2>
<p class="m-b-0 color-white"><a class=" color-white" href="#" title="'.__ENABLE.' Router '.substr($file, 0, -4).'">'.__DISABLE.' <i class="fa fa-lock"></i> </a></p>
<p class="m-b-0 color-white"><a class=" color-white" href="./settings.php?index=mikrotik_ae&id='.substr($file, 0, -4).'" title="'.__EDIT.' Router '.substr($file, 0, -4).'">'.__EDIT.' <i class="fa fa-edit"></i> </a></p>
<p class="m-b-0 color-white"><a class=" color-white" href="./settings.php?index=mikrotik_del&id='.substr($file, 0, -4).'" title="Remove Router '.substr($file, 0, -4).'">'.__DEL.' <i class="fa fa-trash"></i> </a></p>
                                </div>
                            </div>
                        </div>';
}} 
} }}}
}
function load_adm($dir){
$rep=opendir($dir);
while ($file = readdir($rep)) {
 if($file != '..' && $file !='.' && $file !=''){
 if ($file !='index.php' && $file !='index.html' && $file !='.htaccess'){
 if(!is_dir($file)){
echo ' 
                        <div class="card p-20" style="background-color:#fa8564">
                            <div class="media widget-ten">
                                <div class="media-left meida media-middle">
                                    <span  class="color-white"><i class="fa fa-server f-s-40"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2 class="color-white">'.substr($file, 0, -4).'</h2>
<p class="m-b-0 color-white"><a class=" color-white" href="./settings.php?index=administrator_ae&id='.substr($file, 0, -4).'" title="'.__EDIT.' Router '.substr($file, 0, -4).'">'.__EDIT.' <i class="fa fa-edit"></i> </a></p>
                                </div>
                            </div>
                        </div>';


} }}}
}

?>