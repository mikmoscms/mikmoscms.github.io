<?php
switch($_GET['get']){
default:
?>

                <!-- Start Page Content -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="card-two">
                                    <header>
                                        <div class="avatar">
                                            <img src="./assets/images/logo.png" alt="<?php echo __CMS;?>" />
                                        </div>
                                    </header>

                                    <h3><?php echo __CMS;?></h3>
                                    <div class="desc">
									<p><?php echo __WEBTITLLE;?></p>
                                      <p>  <?php echo __WEBDESC;?></p>
                                    </div>
                                    <div class="contacts">
									<?php
 $t_v = file_get_contents('./db/social.txt');
 $rs_v = explode("\n", $t_v);
 array_shift($rs_v);
 $i=1;
 foreach($rs_v as $r_v => $d_v) { $rd_v = explode('|', $d_v);
?> 
<a href="<?php echo $rd_v[2];?>" class="<?php echo $rd_v[1];?>-bg" target="_blank"><i class="fa fa-<?php echo $rd_v[1];?>"></i></a>
<?php } ?>

                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-12">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#update" role="tab">Update</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#referensi" role="tab">Referensi</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="update" role="tabpanel">
                                    <div class="card-body">
                                        <div class="profiletimeline">
                                            <div class="sl-item">
                                                <div class="sl-right">
                                                    <div>
                                                        <blockquote class="m-t-10"></blockquote>
                                                    </div>
													<?php
 $t_v = file_get_contents('./db/update.txt');
 $rs_v = explode("\n", $t_v);
 array_shift($rs_v);
 $i=1;
 foreach($rs_v as $r_v => $d_v) { $rd_v = explode('|', $d_v);
?> 
                                                    <div>
														<strong class="sl-date"><?php echo $rd_v[2];?></strong>
                                                        <blockquote class="m-t-10"><?php echo $rd_v[1];?> : <?php echo $rd_v[3];?>
                                                        </blockquote>
                                                    </div>
                                            <hr>

<?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--second tab-->
                                <div class="tab-pane " id="referensi" role="tabpanel">
                                    <div class="card-body">
                                        <div class="profiletimeline">
                                            <div class="sl-item">
                                                <div class="sl-right">
                                                    <div>
                                                        <blockquote class="m-t-10"></blockquote>
                                                    </div>
													<?php
 $t_r = file_get_contents('./db/ref.txt');
 $rs_r = explode("\n", $t_r);
 array_shift($rs_r);
 $i=1;
 foreach($rs_r as $r_r => $d_r) { $rd_r = explode('|', $d_r);
?> 
                                                    <div>
                                                        <blockquote class="m-t-10">
                                                            <a href="<?php echo $rd_r[2];?>" target="_blank"><?php echo $rd_r[1];?></a>
                                                        </blockquote>
                                                    </div>
                                            <hr>
<?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>

                <!-- End PAge Content -->
				
<?php
break;
}
?>