
<?php 
$_ROUTER = "MIKMOS";
$_LANG = "id";
$_TIMER= "1200";
?>