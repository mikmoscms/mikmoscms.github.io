<div class="left-sidebar">
<div class="scroll-sidebar">
<nav class="sidebar-nav">
<ul id="sidebarnav">
<li class="nav-devider"></li>
<li class="nav-label">Settings</li>
<li><a href="./?load=home" class=""><i class="fa fa-dashboard"></i><span class="hide-menu"><?php echo __DASHBOARD;?></span></a></li>
<li><a href="settings.php?index" class=""><i class="fa fa-gear"></i> <span class="hide-menu"><?php echo __SETTINGS;?></span></a></li>
<li><a href="settings.php?index=administrator" class=""><i class="fa fa-user"></i> <span class="hide-menu"><?php echo __ADM;?></span></a></li>
<li><a href="settings.php?index=mikrotik" class=""><i class="fa fa-wifi"></i> <span class="hide-menu"><?php echo __MK;?></span></a></li>
<li><a href="./?index=vouchers_style" class=""><i class="fa fa-money"></i> <span class="hide-menu"><?php echo __VOUCHERS_STYLE;?></span></a></li>
<li><a href="settings.php?index=update" class=""><i class="fa fa-upload"></i> <span class="hide-menu"><?php echo __UPDATE;?></span></a></li>
<li><a href="./?load=about" class=""><i class="fa fa-code"></i> <span class="hide-menu"><?php echo __ABOUTS;?></span></a></li>			
</ul>
</nav>
</div>
</div>
<div class="page-wrapper">
<div class="container-fluid">