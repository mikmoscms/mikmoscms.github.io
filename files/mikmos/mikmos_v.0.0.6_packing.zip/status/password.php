<?php
error_reporting(0);
require_once('../inc/config.php');
require_once('../lib/fungsi.php');
require_once('../lib/routeros_api.class.php');
if(empty($_LANG)){
include('../inc/lang/id.php');
}else{
include('../inc/lang/'.$_LANG.'.php');
}
include('../inc/ip_mk/'.$_ROUTER.'.php');
$API = new RouterosAPI();
$API->debug = false;
$API->connect($_IPMK, $_USMK, _de(ltrim($_PSMK, __CMS)));

$hotspotuser = $_GET['name'];
if($hotspotuser != ""){
	
	
  $getprofile = $API->comm("/ip/hotspot/user/profile/print");
  $srvlist = $API->comm("/ip/hotspot/print");
  
   
  $getuser = $API->comm("/ip/hotspot/user/print", array(
    "?name"=> "$hotspotuser",
    ));
	
	$userdetails =	$getuser[0];
	$uid = $userdetails['.id'];
	$uname = $userdetails['name'];
  $upass = $userdetails['password'];
  
}

  if(isset($_POST['name'])){

    $name = ($_POST['name']);
    $password = ($_POST['pass']);
	
    $API->comm("/ip/hotspot/user/set", array(
	    ".id"=> "$uid",
	    "name" => "$name",
	    "password" => "$password",
	    ));
    echo '<meta http-equiv="refresh" content="5;URL="editpass.php?name='.$uname.'" />';
	$berhasil = 'Berhasil diperbaharui';
   }
?>


<!DOCTYPE html>
<html lang="<?php echo $_LANG;?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo __WEBDESC;?>">
    <meta name="author" content="<?php echo __CMS;?>">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title><?php echo __WEBTITLLE;?></title>
    <link href="../assets/css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/helper.css" rel="stylesheet">
    <link href="../assets/css/mikmos_style.css" rel="stylesheet">
<script>
function goBack() {
    window.history.back();
}
</script>
<script>
 function PassUser(){
 var x = document.getElementById('passUser');
 if (x.type === 'password') {
 x.type = 'text';
 } else {
 x.type = 'password';
 }}
</script>
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">

        <div class="unix-login">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="login-content card">
                            <div class="login-form">
                                
                                <h3 class="text-center">Akun Anda : <b><?php echo $uname;?> </h3>
<p class="text-center" id="date1"><?php echo __S_title." : " . date("d-m-Y") . "";?></p>
<form autocomplete="off"class="form" method="post" action="">
<div class="row">
<div class="input-group">
        <div class="col-lg-6">
			<input type="password" class="form-control" id="passUser" name="pass" placeholder="Ganti Password" autofocus required="1"  value="<?php echo  $upass;?>"/> 
		</div>
        <div class="col-lg-2">
			<span class="btn btn-danger" title="Show/Hide Password" onclick="PassUser()"><i class="fa fa-eye"></i></span>
		</div>
		<div class="col-lg-4">
			<button type="submit" class="btn btn-danger"><i class="fa fa-search"></i> <?php echo " ".__S_title12;?></button>
		</div>
</div>
</div>
</form>

<div>
<div class="">

	<div style="display:block;"><?php echo $berhasil;?></div>
  
</div>
</div>
</div>
                            </div>
                    </div>
                </div>
            </div>

    </div>
    </div>
    <script src="../assets/js/lib/jquery/jquery.min.js"></script>
    <script src="../assets/js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.slimscroll.js"></script>
    <script src="../assets/js/sidebarmenu.js"></script>
    <script src="../assets/js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="../assets/js/mikmos_script.js"></script>

</body>

</html>



