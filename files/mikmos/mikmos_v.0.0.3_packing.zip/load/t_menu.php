
        <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Main Menu</li>
						
            <li>
                <a href="./?load=home" class=""><i class="fa fa-dashboard"></i><span class="hide-menu"><?php echo __DASHBOARD;?></span></a>
            </li>
            <li>
                <a class="has-arrow  " href="javascript:void(0)" aria-expanded="false">
                    <i class="fa fa-wifi"></i>
                    <span class="hide-menu"><?php echo __HOTSPOT;?></span>
                </a>
                <ul aria-expanded="false" class="collapse">
				 <li><a href="?load=users" class=""><?php echo __USERS;?></a></li>
				 <li><a href="?load=profile" class=""><?php echo __PROFILE;?></a></li>
				 <li><a href="?load=users_active" class=""><?php echo __USERS_ACTIVE;?></a></li>
				 <li><a href="?load=hosts" class=""><?php echo __HOSTS;?></a></li>
				 <li><a href="?load=ipbinding" class=""><?php echo __BINDING;?></a></li>
				 <li><a href="?load=walled_garden" class=""><?php echo __WALLED_GARDEN;?></a></li>
				 <li><a href="?load=cookies" class=""><?php echo __COOKIES;?></a></li>
                </ul>
            </li>
			 <li><a href="?load=vouchers" class=""><i class="fa fa-money"></i> <span class="hide-menu"><?php echo __VOUCHERS;?></a></li>
			 <li><a href="?load=billing" class=""><i class="fa fa-list"></i> <span class="hide-menu"><?php echo __BILLING;?></a></li>
			 <li><a href="?load=users_logs" class=""><i class="fa fa-history"></i> <span class="hide-menu"><?php echo __LOG_ACTIVITY;?></a></li>
            <li>
                <a class="has-arrow  " href="javascript:void(0)" aria-expanded="false">
                    <i class="fa fa-sitemap"></i>
                    <span class="hide-menu"><?php echo __MORE;?></span>
                </a>
                <ul aria-expanded="false" class="collapse">
				 <li><a href="?load=dhcp_lease" class=""><?php echo __DHCPLEASE;?></a></li>
                </ul>
            </li>
			 <li><a href="./settings.php?index" class=""><i class="fa fa-gear"></i> <span class="hide-menu"><?php echo __SETTINGS;?></a></li>
			 <li><a href="?load=about" class=""><i class="fa fa-code"></i> <span class="hide-menu"><?php echo __ABOUTS;?></a></li>
						
						
						
						
						
						
						
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->