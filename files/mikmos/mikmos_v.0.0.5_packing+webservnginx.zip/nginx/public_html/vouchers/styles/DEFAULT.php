<div style="overflow:hidden;position:relative;padding: 0px;margin: 2px;border: 1px solid #555;width:190px;height:125px;float:left;">
<div style="height:20px;">
<div style="float:left;width:45%;">
<img style="margin:5px 0 0 5px;" width="80" height="30" src="<?php echo $v_logo ?>" alt="logo">
</div>
<div style="float:right;margin-right:5px;width:5%;text-align:right;font-size:7px;color:#666;">
<?php echo " [$v_num]";?>
</div>
<div style="float:right;width:45%;text-align:right;font-weight:bold;font-family:Agency FB;color:#555;font-size:32px;">
<small style="font-size:13px;margin-left:-15px;position:absolute;">Rp.</small><?php echo $v_harga.$getuprofile;?>
</div>
</div>
<div style="height:75px;">
<div style="float:left;width:50%;">
<?php if($v_opsi=='up'){ ?>
<div style="padding:0px;border-top:1px solid #777;text-align:center;font-weight:bold;font-size:10px;">MEMBER</div>
<div style="padding:0px;border-top:1px solid #777;border-bottom:1px solid #777;text-align:left;font-weight:bold;font-size:14px;"><small>us:</small><?php echo $v_user;?></div>
<div style="padding:0px;border-bottom:1px solid #777;text-align:left;font-weight:bold;font-size:14px;"><small>ps:</small><?php echo $v_pass;?></div>
<?php }else{ ?>
<div style="padding:0px;border-top:1px solid #777;text-align:center;font-weight:bold;font-size:10px;">VOUCHER</div>
<div style="padding:0px;border-top:1px solid #777;border-bottom:1px solid #777;text-align:center;font-weight:bold;font-size:14px;"><small></small><?php echo $v_user;?></div>
<?php } ?>
</div>
<div style="float:right;width:50%;">

<div style="padding:0 2.5px;text-align:right;font-size:9px;font-weight:bold;color:#333333;">
<?php if($v_valid == "1d"){?>Aktif 1 Hari
<?php }elseif($v_valid == "2d"){?>Aktif 2 Hari
<?php }elseif($v_valid == "3d"){?>Aktif 3 Hari
<?php }elseif($v_valid == "4d"){?>Aktif 4 Hari
<?php }elseif($v_valid == "5d"){?>Aktif 5 Hari
<?php }elseif($v_valid == "6d"){?>Aktif 6 Hari
<?php }elseif($v_valid == "7d"){?>Aktif 1 Minggu
<?php }elseif($v_valid == "14d"){?>Aktif 2 Minggu
<?php }elseif($v_valid == "30d"){?>Aktif 1 Bulan
<?php }else{?>Aktif <span style="text-transform: uppercase;"><?php echo $v_valid ?></span>
<?php }?>
</div>
<div style="padding:0 2.5px;text-align:right;font-size:10px;font-weight:bold;color:#bf0000;">Kuota <?php if(empty($v_dlimit)){;?>Unlimted <?php }else{ echo $v_dlimit;}?></div>
<?php if($v_qrc=="qr"){ ?>
<div style="margin-right:5px;padding:1px;text-align:right;width:50%;float:right;">
<img style="width:100%;" src="<?php echo $v_qrcode ?>" alt="qrcode">
</div>
<?php } ?>
</div>
</div>
<div style="height:25px;color:#fff;font-size:9px;font-weight:bold;margin:0px;padding:2.5px;background:#555;">
<div style="width:50%;">
cek status/logout: http://<?php echo $v_dns;?>
</div>
</div>
</div>