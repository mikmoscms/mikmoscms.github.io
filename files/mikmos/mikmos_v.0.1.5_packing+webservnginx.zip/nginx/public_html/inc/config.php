<?php 
/** 
Yedin Abu Shafa 
Kontak WA: 081802161315
**/
$_ROUTER 	= "EYTALASE";
$_LANG 		= "id";
$_TIMER		= "1200";
?>