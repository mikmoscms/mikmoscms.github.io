
<?php
$_ROUTER 	= "DEMO";
$_LANG = "id";
$_TIMER= "1200";
?>