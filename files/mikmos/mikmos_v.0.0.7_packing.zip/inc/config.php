
<?php 
$_ROUTER = "ONLINE";
$_LANG = "id";
$_TIMER= "1200";
?>