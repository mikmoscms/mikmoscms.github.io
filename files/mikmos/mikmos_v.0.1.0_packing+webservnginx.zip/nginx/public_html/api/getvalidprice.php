<?php
session_start();
error_reporting(0);

include_once('inc/config.php');
include_once('lib/fungsi.php');
include_once('lib/routeros_api.class.php');

$API = new RouterosAPI();
$API->debug = false;
$KONEK_MK=$API->connect($_IPMK, $_USMK, _de(ltrim($_PSMK, __CMS)));

$uprofname = $_GET['name'];
if($uprofname != ""){
  $getprofile = $API->comm("/ip/hotspot/user/profile/print", array("?name" => "$uprofname"));
  $ponlogin = $getprofile[0]['on-login'];
  $getvalid = "Validity : ".explode(",",$ponlogin)[3];
  $getprice = explode(",",$ponlogin)[2];
  $getlock = "| Lock User : ".explode(",",$ponlogin)[6];
  if($getprice == 0){
  }else{
  	if($curency == "Rp" || $curency == "rp" || $curency == "IDR" || $curency == "idr"){
       $price = "| Price : ".$curency." ".number_format($getprice,0,",",".");
     }else{
    $price = "| Price : ".$curency." ".number_format($getprice);
  }
  }
  echo '<b>'.$getvalid.' '.$price.' '.$getlock.'</b>';
}
?>