
<?php 
$_ROUTER = "DEMO_OFFLINE";
$_LANG = "id";
$_TIMER= "1200";
?>