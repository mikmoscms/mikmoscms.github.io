========================
MIKMOS CMS (C) 2018
========================
Kontak 081802161315
========================
Note:
- Jika baru menggunakan MIKMOS cms maka harus install terlebih dahulu.
- Jika ingin install ulang MIKMOS cms, pastikan file di folder inc/ip_mk & inc/administrator hanya tersisa file index.php saja. 
  selain file index.php silahkan untuk dihapus saja, maka jika sudah dihapus akan automatis meminta install kembali.
========================
Change Log:
========================
08/09/18 - v.0.0.3
- Tested BucketAdmin Dashboard
+ ElaAdmin
+ Tested Menu Cookies
+ Ganti sistem Pengaturan Router & Admin
========================
04/09/18 - v.0.0.2
- Folder administrator
+ Folder adm
+ Tested Menu Walled Garden
========================
17/08/18 - v.0.0.1
+ Tested BucketAdmin Dashboard
- Themes Admin LTE 3
+ Tested Multi Bahasa
========================
10/08/18 - Beta
- Themes klorofil
+ Themes Admin LTE 3
+ Tested Menu Hosts
+ Tested Menu IP Binding
========================
01/08/18 - Alpha
+ Themes klorofil
========================